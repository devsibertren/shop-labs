<?php
$servername = "cdlt.nl";
$username = "lush";
$password = "lush666^^^";
$databasename = "vulnlabs";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $databasename);

// Check connection
if (!$conn) {
  die("Connection failed");
}

?>
